export interface Instrument {
  id: number;
  name: string;
}