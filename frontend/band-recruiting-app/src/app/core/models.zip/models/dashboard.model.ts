export interface DashboardSummary {
  totalStudents: number;
  totalRecruiters: number;
  totalOffers: number;
}