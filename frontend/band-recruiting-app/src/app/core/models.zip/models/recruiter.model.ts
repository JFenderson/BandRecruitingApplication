// recruiter.model.ts
export interface Recruiter {
  recruiterId: string;
  userId: string;
  bandId: string;
  firstName: string;
  lastName: string;
  email: string;
}
